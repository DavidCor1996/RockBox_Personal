
iPod Linux readme file
Release 0.18.05

Contents:
	- General Information
	- Controls
	- Misc
	- Misc. Release Notes
	- Romsets and Filenames
	- Configuration File



-- General Information ---------------------------------------------------------

    This is a port of MAME 0.18 to the iPod Linux project.

    In order to build this, you will need to have the development
    tools for the "podzilla2" project installed on your system.
    Please go to the ipodlinux site <http://www.ipodlinux.org> for
    information about accomplishing this.

					    - BleuLlama & Imphasing


-- Controls --------------------------------------------------------------------

    The input layout is defined in the ipodmame.ini file.  The
    primary menu is determined by whether the screen is rotated.
    If when you are holding the iPod such that the screen is upright,
    and "next" (>>) is the top button, then the default input bank
    is "input-rotated", otherwise "input-upright".

    The default controls for this input bank are as follows:

	menu .............. left
	next .............. up
	prev .............. down
	play .............. right
	action ............ push / fire
	hold .............. switch to alternate input bank

    Flipping the 'hold' switch will change input modes.  There can
    be up to three alternate input setups.  They are signified by
    a blinking square in one corner of the display.

    For the default setup, only the GREEN and RED input banks are 
    used.  GREEN is used for extra inputs, while RED is used for 
    system-level control, and are set up as follows:

    GREEN:
	menu .............. player 2 start
	next .............. player 2 coin drop
	prev .............. player 1 coin drop
	play .............. player 1 start
	action ............ exit back to standard input bank
	hold .............. switch to RED input bank

    RED:
	menu .............. quit from iPod Mame
	next .............. exit back to standard input bank
	prev .............. exit back to standard input bank
	play .............. reset emulation
	action ............ exit back to standard input bank
	hold .............. switch to GREEN input bank

    A common sequence would be to start up Pac-Man, and wait for
    the attract sequence to start.  Then flip [hold] on then off.
    (notice the GREEN blinking corner)  then press [prev] to insert
    a coin, [play] to press start, then [action] to switch back to
    the default input bank

    The ipodmame.ini file along with this distribution is documented
    decently enough that you should be able to figure out the format
    and how to use it.


    NOTE: the above layout needs to be explicitly enabled in the ini file.
    in the 'default' section of the file, you should see:

	# input_mechansim can be one of:
	#       INIFILE         use the above layout
	#       INTERNAL        use the hardcoded internal layout
	input_mechanism = INTERNAL

    When this is set to "INIFILE", then the above layout is used,
    when this is set to "INTERNAL" (the default setting), then the
    internal layout is used, which is as follows:

    Base input:
	menu .............. left
	next .............. up
	prev .............. down
	play .............. right
	action ............ push / fire

    flipping 'hold' will switch into the alternate menu.  This also
    turns on a blinking square in the corner of the display.

    Alternate input:
	menu .............. exit
	next .............. reset emulation
	prev .............. player 1 coin drop
	play .............. player 1 start
	action ............ switch back to base input scheme (above)


-- Romsets ---------------------------------------------------------------------

    The list of all files necessary for a specific romset can be
    found in the romlist.ipl.txt file.  In general, romsets have
    been updated to be what the current MAME version (v.104)  expects
    for filenames.

    The current list is of known working romsets.  Others might be 
    working.

    = Homebrew Game Romsets =

	hellopac, matrxpac, aarmada, mspac2

	- aarmada can be downloaded from http://www.widel.com

    = Pac-Man based games =

	pacman, puckman, mspacmab, pengo2u

    = Other games =

	nibbler, fantasy, congo, zaxxon, centiped, milliped, frogger,
	gberet, rushatck, mrdo, ladybug



    The following are untested, but probably should work.

	pacmod, namcopac, hangly, piranha, crush, pengo, penta, frogsega



-- Configuration File ----------------------------------------------------------

	The included "ipodmame.ini" file contains lots of documentation
	that describe how it all works and is layed out.

	You can place it in one of many different locations on your
	iPod:

		/mnt/ipodmame.ini
		/mnt/ipodmame/ipodmame.ini
		/hp/ipodmame.ini
		/hp/ipodmame/ipodmame.ini
		/etc/ipodmame.ini
		/etc/ipodmame/ipodmame.ini
		./ipodmame.ini

	The /etc locations are for HFS or EXT2 ipods.  the /mnt and
	/hp locations are for FAT/Windows iPods.  That way, you can
	either copy the ini file over to your linux partition, or
	just leave it in the data partition.

	These paths are checked in the above order, so if you were
	to install an ipodmame.ini file in /etc, it will be overridden
	by a file in your data partition, if one exists.  Future
	versions might merge all of them together.

	The order that specific sections of the file are read are as
	follows:

		First, [default] is read for settings

		then the game is determined from the command line
		other command line parameters are also read at this time

		next, [gamename] is read in

		if we're running this on the desktop, then finally [desktop]
		is read in.

These romsets are freely available from my pac-man development pages

    http://yorgle.cis.rit.edu/Software/pengo/


These are not under any sort of GPL license... they are complete
and utter freeware.  redistribute and modify them as much as you'd
like to.

There is no warranty expressed or implied with these.  If they
happen to kill your dog, sorry... not my problem.

- Scott Lawrence (BleuLlama)

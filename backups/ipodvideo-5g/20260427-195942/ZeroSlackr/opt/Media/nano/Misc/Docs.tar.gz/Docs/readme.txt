                                                         __
                                                      ,-\| `` _
                                           __  __   ,'   |  _.[\
                                        ././/-<' `-/|    `p'    \
                                    ../'''     \  ,''.  ,-'\   __|
          ........................./ `.` . |    \ \  ]. oY--\,'  |......
          |            __-..      ,' ` \ 'pd     \ `.d/\_    \   |    ||
          |            '`:-]/ .   |  -]U|.P/      `\'\  '-.=--^..'    ||
          |          oo:--  :  `--\  b \ |      _.. -.` ./\.          ||
          |      _.-''__,.-'       \  "-     ,/].,-/\ ` b  d          ||
          |    ,' ,-''             .`+-.    /'',_..  `...'I_          ||
          |   /  /_                '.\  '   V. /8d8|   `O./8'`        ||
          | ,'  J`                  |.       \_`=::  |88/   `         ||
          \/,o'/'                 _ |./-.     |'\'' <J8P'             ||
          P /'/                  ,'|/|L'\,   ./Y ' _ "8               ||
          \' ,|        _  __  /b/  /  `\/\//:]L  L `>o/_,..           ||
          '/ "|      `/ "''YY'        ..\`P    \._:d./,''  \          ||
         |b'  \        \.              \\|'\      _._//\</\I|         ||
         d\    \ .       ` _          PU'' '"''''' '  `8\\]/          ||
         O'     `Y          `-.'__    8.             -/ |\/           ||
        |'        `J\           ./`--.|             ,d  'P            ||
        |            `V\        |     _\ .    _  __P'                 ||
        |,         /    \_.  _   o _,/\\[ `-"--"-'                    ||
         |       ,'       -" 'Y'' `b\.P' \                            ||
         |      /,'                 \   . |                           ||
         |     |,d                   '\  \|                           ||
         ||    |'|                  <h.. |P                           ||
          \      |                   \\/ /          _                 ||
          8.     '.|               /\| P/     _,.--XX`-o_             ||
        ,' ].     ``  _           ./ '/   ,/-X- XX   XX  `..          ||
       |   / `.     `d/\__    .,pY'/-'    `\  XX  XX   XXX  `..       ||
       |  ||   `-P.     P'\.,.\    '\.     `8.  XX  XXX   XX   `o_    ||
       \.  |       `---o/    "-=../=/8".._  'Y\   X    XX   XX    \b  ||
        \  '.           `-- ._      b.\ ( -o-.`\   XX    XX   XX    YoJ|
         `. ' _               `._ Y".].]. -.8/ `2\   XX    XX  _,.b::-"L
          |`._'-._               -` ..-PYb=:,|   \\_   X _,.ooP=-"'___.Yd.
          \___:\. '-..______________:::__::==_____:/o.==8\od=.o--/""""':J|
                 '-._ '-._                          \:==....=------''''
                    '`-._ '".._
                         `-._ '`-._
    ##    ##  ########  ##   `##_ ##-..########  ########  ########  #######
    ##  ##          ##  ##  ##   `##_   `-._ ##  ##    ##     ##     ##
    ########  ########  ########  ## `-########  ########     ##     #######
    ##    ##  ##    ##  ##    ##  ##   ##..  ##`b##  ##       ##          ##
    ##    ##  ########  ##    ##  ##   ########  ##    ##     ##     #######
                                              `b   `.
                                                `.   \.      www.kakiarts.de
             P R E S E N T S                     `.   `.
               " N A N O "                         \    \
        A T   E V O K E   2 0 0 6                  |     |
                                                   |     |
              the first demo                      .'     ||
         for the Apple iPod nano 1G               |      /
                                                 |     ,'
              (version 1.2)                      `----''


CREDITS
-------

    code, additional graphics   - KeyJ  <KeyJ@kakiarts.de>
    design, graphics            - gabi  <gabi@kakiarts.de>
    music                       - <dq>  <dq@kakiarts.de>


REQUIREMENTS
------------

iPod version:
    - an iPod nano, of course. IT WON'T WORK ON OTHER MODELS (read below).
    - a iPodLinux installation on that very device
    - approx. 6 MB of free space on the ext2 partition

PC/Linux version:
    - some modern Linux distribution
    - an x86 PC that was built in this millennium
    - 3D acceleration is not required
    - but OSS sound is (ALSA's OSS emulation does the job, too)

PC/Win32 version:
    - an x86 PC that was built in this millennium
    - some Windows flavour (tested on XP SP2 only)
    - some sound card

GP2X version:
    - a GP2X-F100 (tested with firmware 2.0, but 1.4 should work, too)
    - 8 MB of free space on either the internal NAND memory or an SD card


FAQ a.k.a. QUESTIONS-SOME-SISSIES-MAY-ASK
-----------------------------------------

Q.: Does it work on the nano 2G (September 2006) models?
A.: Unfortunately, no. The new nano models are based on completely
    different hardware. I will definitely do a port as soon as iPodLinux
    works on this device, but until then, you're in bad luck :(

Q.: Can I run it on my iPod/2G/2G/4G/photo/video/Archos/iRiver/Cowon?
A.: As for the non-Apple devices, the answer is a clear 'no'. If you try
    to run it on an iPod other than the nano, it will probably crash; if
    you're lucky, you will at least hear the music :)

Q.: Will you make a port for <insert device name here>?
A.: A port for iPod photo or video is *theoretically* possible. The demo
    would run in a small window there (no fullscreen). However, to develop
    that, I'd need a device to test with. So if anyone feels like lending
    me his/her iPod, I'll probably do a port.

Q.: The screen in the Linux and Windows version is so huge and ugly!
A.: Upon popular request, I added some lame 4x linear upscaling (with
    fancy scanlines :) to the PC-based versions. If you don't like that,
    start the executable with the parameter "-1". A 2x zoom mode is also
    available: use "-2".

Q.: What's that huge "nano.gpe" file for?
A.: That's the executable for the GP2X console. It's common practice to
    statically link executables for that platform, that's why the file
    is so big. If you don't want to run the demo on a GP2X, you may
    delete the file without problems.


INSTALLATION INSTRUCTIONS
-------------------------

Note: The following section is specific to the installation on a real
      device. Also, there's nothing unobvious in here. So, if you don't
      have a nano or are already familiar with iPodLinux, you can easily
      skip it.

First, you need to install iPodLinux. Don't be afraid, it's next to
impossible to "brick" an iPod, you can always return it to a usable
state, only losing the data on it, which you should backup anyway.
There are several good tutorials on how to install iPodLinux on a nano
on the internet, so Google is (again) your friend. If you care, the one
I used is: http://www.linux.com/article.pl?sid=06/03/29/1628212

Then, unpack the demo's tarball somewhere into the ext2 partition of
your iPod. I used /home/nano as the target directory, but any other will
do, to. The tricky part is to start the thing. The last time I checked,
Podzilla wasn't able to execute programs in the iPod's filesystem. My
solution was to disable the Podzilla autostart altogether by editing
/etc/rc and replacing the last line
    podzilla
by
    /sbin/sash
This will leave you with a shell after iPodLinux booted up. Unfortunately,
the shell isn't very usable, as the only letters you will be able to
input are m, d, p, n, l and r for the four buttons and the touch wheel.
So I added a small script called /sbin/d that looks like this:
    #!/bin/sh
    cd /home/nano
    ./nano-ipod
After bootup, you may now press the play button and the center button to
start the demo. You probably won't succeed doing so, because the touch
wheel is *very* sensitive and you usually end up having a bunch of l's
and r's in your command line :) Careful typing with a fingernail should
help. Or better yet, pushing the buttons with a pen tends to work really
flawlessly.


LAST WORDS
----------

Did you know that the iPod nano is the second smallest device (I know
of) that ever has been made a demo for?

Greets go out to 0ok, 5711, 7th Cube, AND, ASD, AY Riders, BASS,
Bauknecht, Bitpopler, Black Maiden, Bomb!, Byterapers, Chorus, Cocoon,
Conspiracy, Cyberpunks Unity, Darklite, Doomsday, Drifters, Ephidrena,
Fairlight, Farbrausch, Fit & Bandwagon, Future Crew, Haujobb,
Hooy-Program, Iris, Jumalauta, Kewlers, Kolor, LKCC, Limp Ninja,
Loonies, MFX, Madwizards, Marshals, Matt Current, Metalvotze, Moppi
Productions, Nah-Kolor, Nesnausk, Northern Dragons, Outracks, Plush,
Portal Process, Rabenauge, Rave Network Overscan, Shitfaced Clowns,
Smash Designs, Stravaganza, Surprise!Productions, Synesthetics, T$,
TRSi, TSCC, The Black Lotus, Titan, Traction, Triad, bypass, calodox,
deranged, exceed, moodsplateau, neuro.concept, plastic, tAAt, �mla�t
Design and everyone else in the scene :)

                                                        -- KeyJ/kakiarts
